/* ========================================
   ShopHack - Gaming Key Store
   JavaScript Interactivity
   ======================================== */

document.addEventListener('DOMContentLoaded', () => {
    // ====== NAVBAR SCROLL EFFECT ======
    const navbar = document.querySelector('.navbar');
    if (navbar) {
        window.addEventListener('scroll', () => {
            if (window.scrollY > 50) {
                navbar.classList.add('scrolled');
            } else {
                navbar.classList.remove('scrolled');
            }
        });
    }

    // ====== ANIMATED COUNTERS ======
    const animateCounter = (element, target, duration = 2000) => {
        let start = 0;
        const increment = target / (duration / 16);
        const suffix = element.dataset.suffix || '';
        const prefix = element.dataset.prefix || '';

        const timer = setInterval(() => {
            start += increment;
            if (start >= target) {
                start = target;
                clearInterval(timer);
            }
            element.textContent = prefix + Math.floor(start).toLocaleString('vi-VN') + suffix;
        }, 16);
    };

    const observeCounters = () => {
        const counters = document.querySelectorAll('[data-count]');
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting && !entry.target.dataset.animated) {
                    entry.target.dataset.animated = 'true';
                    const target = parseInt(entry.target.dataset.count);
                    animateCounter(entry.target, target);
                }
            });
        }, { threshold: 0.5 });

        counters.forEach(counter => observer.observe(counter));
    };

    observeCounters();

    // ====== SCROLL ANIMATIONS ======
    const observeAnimations = () => {
        const elements = document.querySelectorAll('.animate-on-scroll');
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('visible');
                }
            });
        }, { threshold: 0.1, rootMargin: '0px 0px -50px 0px' });

        elements.forEach(el => observer.observe(el));
    };

    observeAnimations();

    // ====== COUNTDOWN TIMER ======
    // Countdown is handled inline in index.php using the actual flash sale end_at time

    // ====== PARTICLES BACKGROUND ======
    const initParticles = () => {
        const container = document.querySelector('.particles-bg');
        if (!container) return;

        for (let i = 0; i < 30; i++) {
            const particle = document.createElement('div');
            particle.classList.add('particle');
            particle.style.left = Math.random() * 100 + '%';
            particle.style.top = Math.random() * 100 + '%';
            particle.style.animationDelay = Math.random() * 6 + 's';
            particle.style.animationDuration = (4 + Math.random() * 8) + 's';
            container.appendChild(particle);
        }
    };

    initParticles();

    // ====== CART MANAGEMENT ======
    window.ShopHack = window.ShopHack || {};

    window.ShopHack.addToCart = (productId, name, price, image) => {
        let cart = JSON.parse(localStorage.getItem('shophack_cart') || '[]');
        const existing = cart.find(item => item.id === productId);

        if (existing) {
            existing.quantity += 1;
        } else {
            cart.push({ id: productId, name, price, image, quantity: 1 });
        }

        localStorage.setItem('shophack_cart', JSON.stringify(cart));
        updateCartCount();
        showNotification(`${name} đã thêm vào giỏ hàng!`);
    };

    window.ShopHack.removeFromCart = (productId) => {
        let cart = JSON.parse(localStorage.getItem('shophack_cart') || '[]');
        cart = cart.filter(item => item.id !== productId);
        localStorage.setItem('shophack_cart', JSON.stringify(cart));
        updateCartCount();
        if (typeof window.ShopHack.renderCart === 'function') {
            window.ShopHack.renderCart();
        }
    };

    window.ShopHack.getCart = () => {
        return JSON.parse(localStorage.getItem('shophack_cart') || '[]');
    };

    const updateCartCount = () => {
        const cart = window.ShopHack.getCart();
        const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
        const badges = document.querySelectorAll('.cart-count');
        badges.forEach(badge => {
            badge.textContent = totalItems;
            badge.style.display = totalItems > 0 ? 'flex' : 'none';
        });
    };

    updateCartCount();

    // ====== NOTIFICATION TOAST ======
    const showNotification = (message, type = 'success') => {
        const toast = document.createElement('div');
        toast.style.cssText = `
            position: fixed;
            bottom: 2rem;
            right: 2rem;
            padding: 1rem 1.5rem;
            background: ${type === 'success' ? 'rgba(34, 197, 94, 0.15)' : 'rgba(239, 68, 68, 0.15)'};
            border: 1px solid ${type === 'success' ? 'rgba(34, 197, 94, 0.3)' : 'rgba(239, 68, 68, 0.3)'};
            border-radius: 12px;
            color: ${type === 'success' ? '#22c55e' : '#ef4444'};
            font-family: 'Rajdhani', sans-serif;
            font-weight: 600;
            font-size: 0.9375rem;
            z-index: 9999;
            backdrop-filter: blur(20px);
            animation: slideInUp 0.3s ease;
            display: flex;
            align-items: center;
            gap: 0.75rem;
        `;
        toast.innerHTML = `
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                ${type === 'success'
                    ? '<path d="M20 6L9 17l-5-5"/>'
                    : '<circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/>'}
            </svg>
            <span>${message}</span>
        `;
        document.body.appendChild(toast);

        setTimeout(() => {
            toast.style.opacity = '0';
            toast.style.transform = 'translateY(10px)';
            toast.style.transition = 'all 0.3s ease';
            setTimeout(() => toast.remove(), 300);
        }, 3000);
    };

    window.ShopHack.showNotification = showNotification;

    // ====== SEARCH FUNCTIONALITY ======
    const searchInput = document.querySelector('.search-bar input');
    if (searchInput) {
        searchInput.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') {
                const query = searchInput.value.trim();
                if (query) {
                    window.location.href = `category.php?search=${encodeURIComponent(query)}`;
                }
            }
        });
    }
});
